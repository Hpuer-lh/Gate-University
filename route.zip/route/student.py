from flask import Blueprint, render_template, request, redirect, url_for, flash
from models import db, Student

student_bp = Blueprint('student', __name__, url_prefix='/student')

@student_bp.route('/')
def index():
    return render_template('student/index.html')

@student_bp.route('/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        major = request.form['major']

        new_student = Student(name=name, age=age, major=major)
        db.session.add(new_student)
        db.session.commit()
        flash('学生信息添加成功！')
        return render_template('student/add_student.html', student=new_student)

    return render_template('student/add_student.html')

@student_bp.route('/delete', methods=['GET', 'POST'])
def delete_student():
    if request.method == 'POST':
        student_id = request.form['student_id']
        student = Student.query.get(student_id)
        if student:
            student_info = {
                'student_id': student.student_id,
                'name': student.name,
                'age': student.age,
                'major': student.major
            }
            db.session.delete(student)
            db.session.commit()
            flash('学生信息删除成功！')
            return render_template('student/delete_student.html', student=student_info, deleted=True)
        else:
            flash('学生信息删除失败，未找到该学生！')
        return redirect(url_for('student/delete_student.html'))

    return render_template('student/delete_student.html')

@student_bp.route('/edit', methods=['GET', 'POST'])
def edit_student():
    if request.method == 'POST':
        student_id = request.form['student_id']
        student = Student.query.get(student_id)
        if student:
            old_info = {
                'name': student.name,
                'age': student.age,
                'major': student.major
            }
            student.name = request.form['name']
            student.age = request.form['age']
            student.major = request.form['major']
            db.session.commit()
            flash('学生信息修改成功！')
            return render_template('student/edit_student.html', student=student, old_info=old_info, edited=True)
        else:
            flash('学生信息修改失败，未找到该学生！')
        return redirect(url_for('student/edit_student.html'))

    return render_template('student/edit_student.html')

@student_bp.route('/search', methods=['GET', 'POST'])
def search_student():
    students = []
    if request.method == 'POST':
        search_term = request.form['search_term']
        students = Student.query.filter(Student.name.contains(search_term)).all()
        if students:
            flash('学生信息查询成功！')
        else:
            flash('学生信息查询失败，未找到相关学生！')

    return render_template('student/search_student.html', students=students)