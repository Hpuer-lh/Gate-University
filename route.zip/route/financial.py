from flask import Blueprint, render_template, request, redirect, url_for, flash
from models import db, FinancialRecord

financial_bp = Blueprint('financial', __name__, url_prefix='/financial')

@financial_bp.route('/')
def index():
    return render_template('financial/index.html')

@financial_bp.route('/add_record', methods=['GET', 'POST'])
def add_record():
    if request.method == 'POST':
        student_id = request.form.get('student_id')
        amount = request.form.get('amount')
        due_date = request.form.get('due_date')
        status = request.form.get('status')

        if not student_id or not amount or not due_date or not status:
            flash('所有字段都是必填的！')
            return redirect(url_for('financial.add_record'))

        new_record = FinancialRecord(
            student_id=student_id,
            amount=amount,
            due_date=due_date,
            status=status
        )
        db.session.add(new_record)
        db.session.commit()
        flash('财务记录添加成功！')
        return redirect(url_for('financial.add_record'))

    return render_template('financial/add_record.html')

@financial_bp.route('/delete_record', methods=['GET', 'POST'])
def delete_record():
    deleted = False
    record = None
    if request.method == 'POST':
        record_id = request.form.get('record_id')
        record = FinancialRecord.query.get(record_id)
        if record:
            db.session.delete(record)
            db.session.commit()
            flash('财务记录删除成功！')
            deleted = True
        else:
            flash('财务记录删除失败，未找到该记录！')
        return render_template('financial/delete_record.html', deleted=deleted, record=record)

    return render_template('financial/delete_record.html', deleted=deleted, record=record)

@financial_bp.route('/edit_record', methods=['GET', 'POST'])
def edit_record():
    if request.method == 'POST':
        record_id = request.form.get('record_id')
        record = FinancialRecord.query.get(record_id)
        if record:
            record.student_id = request.form.get('student_id')
            record.amount = request.form.get('amount')
            record.due_date = request.form.get('due_date')
            record.status = request.form.get('status')
            db.session.commit()
            flash('财务记录修改成功！')
        else:
            flash('财务记录修改失败，未找到该记录！')
        return redirect(url_for('financial.edit_record'))

    return render_template('financial/edit_record.html')

@financial_bp.route('/search_record', methods=['GET', 'POST'])
def search_record():
    records = []
    if request.method == 'POST':
        search_term = request.form.get('search_term')
        records = FinancialRecord.query.filter(FinancialRecord.record_id.contains(search_term)).all()
        if records:
            flash('财务记录查询成功！')
        else:
            flash('财务记录查询失败，未找到相关记录！')

    return render_template('financial/search_record.html', records=records)