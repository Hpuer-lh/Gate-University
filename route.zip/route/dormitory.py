from flask import Blueprint, render_template, request, redirect, url_for, flash
from models import db, DormitoryAssignment, AccessRecord, Student

dormitory_bp = Blueprint('dormitory', __name__, url_prefix='/dormitory')

@dormitory_bp.route('/')
def index():
    return render_template('dormitory/index.html')


@dormitory_bp.route('/assignment_index')
def assignment_index():
    return render_template('dormitory/assignment_index.html')

@dormitory_bp.route('/access_index')
def access_index():
    return render_template('dormitory/access_index.html')

# 添加宿舍分配
@dormitory_bp.route('/add_assignment', methods=['GET', 'POST'])
def add_assignment():
    if request.method == 'POST':
        student_id = request.form['student_id']
        dormitory_id = request.form['dormitory_id']
        room_number = request.form['room_number']

        new_assignment = DormitoryAssignment(student_id=student_id, dormitory_id=dormitory_id, room_number=room_number)
        db.session.add(new_assignment)
        db.session.commit()
        flash('宿舍分配添加成功！')
        return redirect(url_for('dormitory.add_assignment'))

    return render_template('dormitory/add_assignment.html')

# 删除宿舍分配
@dormitory_bp.route('/delete_assignment', methods=['GET', 'POST'])
def delete_assignment():
    if request.method == 'POST':
        assignment_id = request.form['assignment_id']
        assignment = DormitoryAssignment.query.get(assignment_id)
        if assignment:
            db.session.delete(assignment)
            db.session.commit()
            flash('宿舍分配删除成功！')
        else:
            flash('宿舍分配删除失败，未找到该分配！')
        return redirect(url_for('dormitory.delete_assignment'))

    return render_template('dormitory/delete_assignment.html')

# 修改宿舍分配
@dormitory_bp.route('/edit_assignment', methods=['GET', 'POST'])
def edit_assignment():
    edited = False
    assignment = None
    if request.method == 'POST':
        assignment_id = request.form['assignment_id']
        student_id = request.form['student_id']
        dormitory_id = request.form['dormitory_id']
        room_number = request.form['room_number']

        # 查找并更新宿舍分配记录
        assignment = DormitoryAssignment.query.get(assignment_id)
        if assignment:
            assignment.student_id = student_id
            assignment.dormitory_id = dormitory_id
            assignment.room_number = room_number
            db.session.commit()
            edited = True

    return render_template('dormitory/edit_assignment.html', edited=edited, assignment=assignment)

# 查询宿舍分配
@dormitory_bp.route('/search_assignment', methods=['GET', 'POST'])
def search_assignment():
    assignments = []
    if request.method == 'POST':
        search_term = request.form['search_term']
        assignments = DormitoryAssignment.query.filter(DormitoryAssignment.room_number.contains(search_term)).all()
        if assignments:
            flash('宿舍分配查询成功！')
        else:
            flash('宿舍分配查询失败，未找到相关分配！')

    return render_template('dormitory/search_assignment.html', assignments=assignments)

# 添加进出记录
@dormitory_bp.route('/add_access_record', methods=['GET', 'POST'])
def add_access_record():
    new_record = None
    if request.method == 'POST':
        student_id = request.form['student_id']
        access_time = request.form['access_time']
        access_type = request.form['access_type']

        # 插入进出记录
        new_record = AccessRecord(student_id=student_id, access_time=access_time, access_type=access_type)
        db.session.add(new_record)
        db.session.commit()

        flash('进出记录添加成功！', 'success')

    return render_template('dormitory/add_access_record.html', new_record=new_record)

# 删除进出记录
@dormitory_bp.route('/delete_access_record', methods=['GET', 'POST'])
def delete_access_record():
    if request.method == 'POST':
        record_id = request.form['record_id']
        record = AccessRecord.query.get(record_id)
        if record:
            db.session.delete(record)
            db.session.commit()
            flash('进出记录删除成功！')
        else:
            flash('进出记录删除失败，未找到该记录！')
        return redirect(url_for('dormitory.delete_access_record'))

    return render_template('dormitory/delete_access_record.html')

# 修改进出记录
@dormitory_bp.route('/edit_access_record', methods=['GET', 'POST'])
def edit_access_record():
    if request.method == 'POST':
        record_id = request.form['record_id']
        record = AccessRecord.query.get(record_id)
        if record:
            record.student_id = request.form['student_id']
            record.access_time = request.form['access_time']
            record.access_type = request.form['access_type']
            db.session.commit()
            flash('进出记录修改成功！')
        else:
            flash('进出记录修改失败，未找到该记录！')
        return redirect(url_for('dormitory.edit_access_record'))

    return render_template('dormitory/edit_access_record.html')

# 查询进出记录
@dormitory_bp.route('/search_access_records', methods=['GET', 'POST'])
def search_access_records():
    access_records = []
    if request.method == 'POST':
        search_term = request.form['search_term']
        access_records = AccessRecord.query.filter(AccessRecord.access_time.contains(search_term)).all()
        if access_records:
            flash('进出记录查询成功！')
        else:
            flash('进出记录查询失败，未找到相关记录！')

    return render_template('dormitory/search_access_records.html', access_records=access_records)

from datetime import datetime, time
# 查询早6点之前和晚11点之后的进出记录
from datetime import datetime, time

@dormitory_bp.route('/search_early_late_records', methods=['GET'])
def search_early_late_records():
    today = datetime.today().date()
    early_time = datetime.combine(today, time(6, 0, 0))
    late_time = datetime.combine(today, time(23, 0, 0))
    next_day = datetime.combine(today, time(23, 59, 59))

    early_records = AccessRecord.query.filter(AccessRecord.access_time >= datetime.combine(today, time(0, 0, 0)), AccessRecord.access_time <= early_time).all()
    late_records = AccessRecord.query.filter(AccessRecord.access_time >= late_time, AccessRecord.access_time <= next_day).all()

    in_records = [record for record in early_records + late_records if record.access_type == 'in']
    out_records = [record for record in early_records + late_records if record.access_type == 'out']

    return render_template('dormitory/search_early_late_records.html', in_records=in_records, out_records=out_records)