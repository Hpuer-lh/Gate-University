from flask import Blueprint, render_template, request, redirect, url_for, flash
from models import db, Course, Student, CourseSelection, PracticalExperiment

academic_bp = Blueprint('academic', __name__, url_prefix='/academic')

@academic_bp.route('/')
def index():
    return render_template('academic/index.html')

# 课程管理
@academic_bp.route('/course_index')
def course_index():
    return render_template('academic/course_index.html')

@academic_bp.route('/add_course', methods=['GET', 'POST'])
def add_course():
    if request.method == 'POST':
        name = request.form.get('name', '')
        code = request.form.get('code', '')
        instructor = request.form.get('instructor', '')
        if name and code and instructor:
            new_course = Course(course_name=name, location=code, teacher=instructor)
            db.session.add(new_course)
            db.session.commit()
            flash('课程添加成功！')
        else:
            flash('所有字段都是必填的！')
    return render_template('academic/add_course.html')

@academic_bp.route('/delete_course', methods=['GET', 'POST'])
def delete_course():
    if request.method == 'POST':
        course_id = request.form.get('course_id', '')
        if course_id:
            course = Course.query.get(course_id)
            if course:
                db.session.delete(course)
                db.session.commit()
                flash('课程删除成功！')
            else:
                flash('课程删除失败，未找到该课程！')
        else:
            flash('课程ID是必填的！')
    return render_template('academic/delete_course.html')

@academic_bp.route('/edit_course', methods=['GET', 'POST'])
def edit_course():
    if request.method == 'POST':
        course_id = request.form.get('course_id', '')
        if course_id:
            course = Course.query.get(course_id)
            if course:
                course.course_name = request.form.get('name', course.course_name)
                course.location = request.form.get('code', course.location)
                course.teacher = request.form.get('instructor', course.teacher)
                db.session.commit()
                flash('课程修改成功！')
            else:
                flash('课程修改失败，未找到该课程！')
        else:
            flash('课程ID是必填的！')
    return render_template('academic/edit_course.html')

@academic_bp.route('/search_course', methods=['GET', 'POST'])
def search_course():
    courses = []
    if request.method == 'POST':
        search_term = request.form.get('search_term', '')
        if search_term:
            courses = Course.query.filter(Course.course_name.contains(search_term)).all()
            if courses:
                flash('课程查询成功！')
            else:
                flash('课程查询失败，未找到相关课程！')
        else:
            flash('搜索词是必填的！')
    return render_template('academic/search_course.html', courses=courses)

# 选课管理
@academic_bp.route('/selection_index')
def selection_index():
    return render_template('academic/selection_index.html')

@academic_bp.route('/add_selection', methods=['GET', 'POST'])
def add_selection():
    if request.method == 'POST':
        student_id = request.form['student_id']
        course_id = request.form['course_id']
        new_selection = CourseSelection(student_id=student_id, course_id=course_id)
        db.session.add(new_selection)
        db.session.commit()
        flash('选课添加成功！')
    return render_template('academic/add_selection.html')

@academic_bp.route('/delete_selection', methods=['GET', 'POST'])
def delete_selection():
    if request.method == 'POST':
        selection_id = request.form['selection_id']
        selection = CourseSelection.query.get(selection_id)
        if selection:
            db.session.delete(selection)
            db.session.commit()
            flash('选课删除成功！')
        else:
            flash('选课删除失败，未找到该选课记录！')
    return render_template('academic/delete_selection.html')

@academic_bp.route('/edit_selection', methods=['GET', 'POST'])
def edit_selection():
    if request.method == 'POST':
        selection_id = request.form['selection_id']
        selection = CourseSelection.query.get(selection_id)
        if selection:
            selection.student_id = request.form['student_id']
            selection.course_id = request.form['course_id']
            db.session.commit()
            flash('选课修改成功！')
        else:
            flash('选课修改失败，未找到该选课记录！')
    return render_template('academic/edit_selection.html')

@academic_bp.route('/search_selection', methods=['GET', 'POST'])
def search_selection():
    selections = []
    if request.method == 'POST':
        search_term = request.form['search_term']
        # 查询学生
        student = Student.query.filter_by(name=search_term).first()
        if student:
            selections = CourseSelection.query.filter_by(student_id=student.student_id).all()
        else:
            # 查询课程
            course = Course.query.filter_by(course_name=search_term).first()
            if course:
                selections = CourseSelection.query.filter_by(course_id=course.course_id).all()
            else:
                flash('未找到相关学生或课程')
    return render_template('academic/search_selection.html', selections=selections)

# 实验管理
@academic_bp.route('/experiment_index')
def experiment_index():
    return render_template('academic/experiment_index.html')

@academic_bp.route('/add_experiment', methods=['GET', 'POST'])
def add_experiment():
    if request.method == 'POST':
        title = request.form['title']
        course_id = request.form['course_id']
        description = request.form['description']
        new_experiment = PracticalExperiment(experiment_name=title, course_id=course_id, description=description)
        db.session.add(new_experiment)
        db.session.commit()
        flash('实验添加成功！')
    return render_template('academic/add_experiment.html')

@academic_bp.route('/delete_experiment', methods=['GET', 'POST'])
def delete_experiment():
    if request.method == 'POST':
        experiment_id = request.form['experiment_id']
        experiment = PracticalExperiment.query.get(experiment_id)
        if experiment:
            db.session.delete(experiment)
            db.session.commit()
            flash('实验删除成功！')
        else:
            flash('实验删除失败，未找到该实验！')
    return render_template('academic/delete_experiment.html')

@academic_bp.route('/edit_experiment', methods=['GET', 'POST'])
def edit_experiment():
    if request.method == 'POST':
        experiment_id = request.form['experiment_id']
        experiment = PracticalExperiment.query.get(experiment_id)
        if experiment:
            experiment.experiment_name = request.form['title']
            experiment.course_id = request.form['course_id']
            experiment.description = request.form['description']
            db.session.commit()
            flash('实验修改成功！')
        else:
            flash('实验修改失败，未找到该实验！')
    return render_template('academic/edit_experiment.html')

@academic_bp.route('/search_experiment', methods=['GET', 'POST'])
def search_experiment():
    experiments = []
    if request.method == 'POST':
        search_term = request.form['search_term']
        experiments = PracticalExperiment.query.filter(PracticalExperiment.experiment_name.contains(search_term)).all()
        if experiments:
            flash('实验查询成功！')
        else:
            flash('实验查询失败，未找到相关实验！')
    return render_template('academic/search_experiment.html', experiments=experiments)