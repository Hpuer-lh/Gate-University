from flask import Blueprint, render_template
from models import db, Student, Course, PracticalExperiment as Experiment, DormitoryAssignment, AccessRecord, CourseSelection, FinancialRecord

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/')
def index():
    students = Student.query.all()
    courses = Course.query.all()
    experiments = Experiment.query.all()
    dormitory_assignments = DormitoryAssignment.query.join(Student, DormitoryAssignment.student_id == Student.student_id).add_columns(Student.name).all()
    access_records = AccessRecord.query.join(Student, AccessRecord.student_id == Student.student_id).add_columns(Student.name).all()
    course_selections = CourseSelection.query.join(Student, CourseSelection.student_id == Student.student_id).add_columns(Student.name).all()
    financial_records = FinancialRecord.query.join(Student, FinancialRecord.student_id == Student.student_id).add_columns(Student.name).all()
    return render_template('admin/index.html', students=students, courses=courses, experiments=experiments, dormitory_assignments=dormitory_assignments, access_records=access_records, course_selections=course_selections, financial_records=financial_records)